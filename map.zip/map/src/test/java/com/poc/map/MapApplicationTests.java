package com.poc.map;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MapApplicationTests {

	@Test
	void contextLoads() {
	}

}
