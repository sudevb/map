package com.poc.map.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.poc.map.dto.StageDto;
import com.poc.map.dto.ProductDto;

@Mapper(componentModel = "spring")
public interface ProductMapper {

    ProductMapper MAPPER = Mappers.getMapper( ProductMapper.class );

    @Mapping(target = "name", expression = "java(parseName(s.getRecord()))")
    @Mapping(target = "description", expression = "java(parseDescription(s.getRecord()))")
    ProductDto toTarget(StageDto s);

    default String parseName(String record) {
        // Logic to parse and extract name from record
        // Example logic:
        return record.split(",")[0];
    }

    default String parseDescription(String record) {
        // Logic to parse and extract description from record
        // Example logic:
        return record.split(",")[1];
    }
}
