package com.poc.map.mapper;

import com.poc.map.config.MappingConfigLoader;
import com.poc.map.dto.StageDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.lang.reflect.Field;
import java.util.Map;

@Component
public class DynamicMapper {
    private final MappingConfigLoader configLoader;

    @Autowired
    public DynamicMapper(MappingConfigLoader configLoader) {
        this.configLoader = configLoader;
    }

    public Object map(StageDto stageDto) {
        Map<String, Map<String, Object>> mappings = configLoader.getMappings();
        Map<String, Object> typeMapping = mappings.get(stageDto.getType());

        if (typeMapping == null) {
            throw new IllegalArgumentException("Unknown type: " + stageDto.getType());
        }

        try {
            Class<?> targetClass = Class.forName((String) typeMapping.get("class"));
            Object targetObject = targetClass.getDeclaredConstructor().newInstance();

            String[] recordFields = stageDto.getRecord().split(",");

            Map<String, Integer> fieldMappings = (Map<String, Integer>) typeMapping.get("fields");
            for (Map.Entry<String, Integer> entry : fieldMappings.entrySet()) {
                String fieldName = entry.getKey();
                int fieldIndex = entry.getValue();

                Field field = targetClass.getDeclaredField(fieldName);
                field.setAccessible(true);
                field.set(targetObject, recordFields.length > fieldIndex ? recordFields[fieldIndex] : null);
            }

            return targetObject;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to map object", e);
        }
    }
}
