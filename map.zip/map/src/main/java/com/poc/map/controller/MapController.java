package com.poc.map.controller;

import com.poc.map.dto.ProductDto;
import com.poc.map.dto.RiskDto;
import com.poc.map.dto.StageDto;
import com.poc.map.dto.TradeDto;
import com.poc.map.mapper.DynamicMapper;
import com.poc.map.mapper.ProductMapper;
import com.poc.map.mapper.RiskMapper;
import com.poc.map.mapper.TradeMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class MapController {

    @Autowired
    DynamicMapper dynamicMapper;
    //MappingService mappingService;

    @GetMapping("/testProduct")
    public ProductDto mapProduct() {
        StageDto stageDto = new StageDto("product,description", "ProductType");

        ProductDto productDto = ProductMapper.MAPPER.toTarget( stageDto );
        System.out.println( productDto);
        return productDto;
    }

    @GetMapping("/testRisk")
    public RiskDto mapRisk() {
        StageDto stageDto = new StageDto("riskid1,description1", "ProductType");

        RiskDto riskDto = RiskMapper.MAPPER.toTarget( stageDto );
        System.out.println( riskDto);
        return riskDto;
    }

    @GetMapping("/testTrade")
    public TradeDto mapTrade() {
        StageDto stageDto = new StageDto("record,category,type", "TradeType");

        TradeDto tradeDto = TradeMapper.MAPPER.toTarget( stageDto );
        System.out.println( tradeDto);
        return tradeDto;
    }

    /*@GetMapping("/map")
    public Object map(@RequestParam String record, @RequestParam String type) {
        StageDto stageDto = new StageDto();
        stageDto.setRecord(record);
        stageDto.setType(type);

        return mappingService.mapToTarget(stageDto);
    }*/

    @GetMapping("/map-file")
    public Object map(@RequestParam String record, @RequestParam String type) {
        StageDto stageDto = new StageDto();
        stageDto.setRecord(record);
        stageDto.setType(type);
        return dynamicMapper.map(stageDto);
    }
}
