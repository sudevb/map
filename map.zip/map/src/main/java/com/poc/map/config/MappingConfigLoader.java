package com.poc.map.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;

@Component
public class MappingConfigLoader {
    private static final String CONFIG_FILE = "src/main/resources/mappings.json";
    private Map<String, Map<String, Object>> mappings;

    public MappingConfigLoader() {
        try {
            byte[] jsonData = Files.readAllBytes(Paths.get(CONFIG_FILE));
            ObjectMapper objectMapper = new ObjectMapper();
            mappings = objectMapper.readValue(jsonData, Map.class);
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to load mapping configuration");
        }
    }

    public Map<String, Map<String, Object>> getMappings() {
        return mappings;
    }
}
